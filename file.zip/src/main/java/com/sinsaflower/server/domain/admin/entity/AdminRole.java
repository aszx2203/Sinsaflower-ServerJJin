package com.sinsaflower.server.domain.admin.entity;

import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.Setter;


public enum AdminRole {
    ADMIN,
    PARTNER
}