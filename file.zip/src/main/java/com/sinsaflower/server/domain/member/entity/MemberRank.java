package com.sinsaflower.server.domain.member.entity;

public enum MemberRank {
    Bronze,
    Silver,
    Gold,
    Platinum,
    Diamond
}
